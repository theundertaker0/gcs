<?php $__env->startSection('head'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row text-center paddingSuperior">
    <div class="col-12 col-md-4">
        <h2><?php echo e(Auth::user()->name); ?>&nbsp;<?php echo e(Auth::user()->last_name); ?></h2>
        <hr />
        <img src="<?php echo e(asset('uploads/avatars/'.Auth::user()->avatar)); ?>" alt="Avatar" class="avatar margenInferior">
        <div class="row margenInferior">
            <a href="/edituser" class="btn btn-lg btn-block btn-warning btnPrincipal"><span class="fa fa-edit "></span>&nbsp;Editar Perfil</a>
            <a href="" href="<?php echo e(route('logout')); ?>" class="btn btn-lg btn-block btn-warning btnPrincipal" onclick="event.preventDefault();document.getElementById('logout-form').submit();"><span class="fa fa-sign-out-alt "></span>&nbsp; Salir</a>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
        </div>
        <h2>Productos</h2>
        <hr />
        <div class="row margenInferior">
            <a href="" class="btn btn-lg btn-block btn-warning btnPrincipal"><span class="fa fa-plus-square "></span>&nbsp;Nuevo Producto</a>
            <a href="" class="btn btn-lg btn-block btn-warning btnPrincipal"><span class="fa fa-eye "></span>&nbsp;Mis Productos</a>
        </div>
        <h2>Garantías</h2>
        <hr />
        <div class="row margenInferior">
            <a href="" class="btn btn-lg btn-block btn-warning btnPrincipal"><span class="fa fa-eye "></span>&nbsp;Mis Garantías</a>
        </div>
        <h2>Empresas</h2>
        <hr />
        <div class="row margenInferior">
            <a href="<?php echo e(route('enterprises')); ?>" class="btn btn-lg btn-block btn-warning btnPrincipal"><span class="fa fa-eye "></span>&nbsp;Empresarios</a>
        </div>
    </div>
    <div class="col-12 col-md-8 text-center paddingSuperiorGrande">
        <h1 class="primaryColor margenInferior">Garantía Completa y Segura</h1>
        <img src="<?php echo e(asset('img/logogcs.png')); ?>" alt="">
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.masterFront', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>