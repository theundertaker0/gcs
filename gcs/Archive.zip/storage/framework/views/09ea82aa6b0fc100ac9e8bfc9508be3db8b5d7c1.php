<?php $__env->startSection('head'); ?>


<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <div class="row text-center margenInferior paddingSuperior">
        <div class="col-12">
            <?php if(session('success')): ?>
            <p class="alert-success"><?php echo e(session('success')); ?><a href="<?php echo e(url('/')); ?>" class="btn btn-link"> Regresar a página principal</a></p>
            <?php endif; ?>
            <img src="<?php echo e(asset('uploads/avatars/'.Auth::user()->avatar)); ?>" alt="Logo GCS" class="avatar">
        </div>
    </div>

    <div class="row">
        <div class="col-12 col-md-6 offset-md-3">
            <form method="POST" action="<?php echo e(route('storeuser')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="form-group row">
                    <input type="file" class="" id="avatar" name="avatar" accept="image/*">
                    <?php if($errors->has('avatar')): ?>
                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('avatar')); ?></strong>
                                    </span>
                    <?php endif; ?>
                </div>
                <div class="form-group row">
                    <label for="name"><?php echo e(__('Nombre')); ?>*</label>
                    <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e($user->name); ?>" required autofocus>

                    <?php if($errors->has('name')): ?>
                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                    <?php endif; ?>
                </div>

                <div class="form-group row">
                    <label for="last_name"><?php echo e(__('Apellidos')); ?></label>
                    <input id="last_name" type="text" class="form-control<?php echo e($errors->has('last_name') ? ' is-invalid' : ''); ?>" name="last_name" value="<?php echo e($user->last_name); ?>" autofocus>

                    <?php if($errors->has('last_name')): ?>
                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('lastname')); ?></strong>
                                    </span>
                    <?php endif; ?>
                </div>

                <div class="form-group row">
                    <label for="email2"><?php echo e(__('Correo electrónico')); ?>*</label>
                    <input id="email2" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email2" value="<?php echo e($user->email); ?>" required disabled>
                    <input type="hidden" value="<?php echo e($user->email); ?>" name="email" id="email">
                    <?php if($errors->has('email')): ?>
                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                    <?php endif; ?>
                </div>


                <div class="form-group row">
                    <label for="address"><?php echo e(__('Dirección')); ?></label>
                    <input id="address" type="text" class="form-control<?php echo e($errors->has('address') ? ' is-invalid' : ''); ?>" name="address" value="<?php echo e($user->address); ?>" autofocus>

                    <?php if($errors->has('address')): ?>
                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('address')); ?></strong>
                                    </span>
                    <?php endif; ?>
                </div>

                <div class="row">
                    <div class="form-group col-4" style="padding-left: 0px">
                        <label for="city"><?php echo e(__('Ciudad')); ?></label>
                        <input id="city" type="text" class="form-control<?php echo e($errors->has('city') ? ' is-invalid' : ''); ?>" name="city" value="<?php echo e($user->city); ?>" autofocus>

                        <?php if($errors->has('city')): ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('city')); ?></strong>
                                    </span>
                        <?php endif; ?>
                    </div>


                    <div class="form-group col-4" style="padding: 0px">
                        <label for="state"><?php echo e(__('Estado')); ?></label>
                        <select name="state" id="state" class="form-control state" value="<?php echo e($user->state); ?>" autofocus>
                            <option value="null">Seleccione...</option>
                            <option value="Aguascalientes">Aguascalientes</option>
                            <option value="Baja California">Baja California</option>
                            <option value="Baja California Sur">Baja California Sur</option>
                            <option value="Campeche">Campeche</option>
                            <option value="Chiapas">Chiapas</option>
                            <option value="Chihuahua">Chihuahua</option>
                            <option value="Coahuila">Coahuila</option>
                            <option value="Colima">Colima</option>
                            <option value="Distrito Federal">Distrito Federal</option>
                            <option value="Durango">Durango</option>
                            <option value="Estado de México">Estado de México</option>
                            <option value="Guanajuato">Guanajuato</option>
                            <option value="Guerrero">Guerrero</option>
                            <option value="Hidalgo">Hidalgo</option>
                            <option value="Jalisco">Jalisco</option>
                            <option value="Michoacán">Michoacán</option>
                            <option value="Morelos">Morelos</option>
                            <option value="Nayarit">Nayarit</option>
                            <option value="Nuevo León">Nuevo León</option>
                            <option value="Oaxaca">Oaxaca</option>
                            <option value="Puebla">Puebla</option>
                            <option value="Querétaro">Querétaro</option>
                            <option value="Quintana Roo">Quintana Roo</option>
                            <option value="San Luis Potosí">San Luis Potosí</option>
                            <option value="Sinaloa">Sinaloa</option>
                            <option value="Sonora">Sonora</option>
                            <option value="Tabasco">Tabasco</option>
                            <option value="Tamaulipas">Tamaulipas</option>
                            <option value="Tlaxcala">Tlaxcala</option>
                            <option value="Veracruz">Veracruz</option>
                            <option value="Yucatán">Yucatán</option>
                            <option value="Zacatecas">Zacatecas</option>
                            <option value="Otro">Otro</option>
                        </select>
                    </div>

                    <div class="form-group col-4" style="padding-right: 0px;padding-left: 0px;">
                        <label for="cp"><?php echo e(__('CP')); ?></label>
                        <input id="cp" type="text" class="form-control<?php echo e($errors->has('cp') ? ' is-invalid' : ''); ?>" name="cp" value="<?php echo e($user->cp); ?>" autofocus>

                        <?php if($errors->has('cp')): ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('cp')); ?></strong>
                                    </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group row text-center margenInferior">
                    <div class="col-12">
                        <button type="submit" class="btn btn-warning btnPrincipal">
                            <span class="fa fa-sign-in-alt"></span>&nbsp;<?php echo e(__('Editar')); ?>

                        </button>
                    </div>
                </div>

            </form>
            <div class="row text-center">
                <div class="col-12">
                    <a href="<?php echo e(route('changepass')); ?>" class="btn btn-link">Si necesita cambiar su contraseña de clic en este enlace</a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
        $(document).ready(function(){
            $('#state').select2();
            $('#avatar').fileselect({
                language:'es',
                allowedNumberOfFiles: 1, // default: false, no limitation
                allowedFileExtensions: ['jpg','png','gif','jpeg'],// default: false, all extensions allowed
                allowedFileSize: 2097152, // 2MB, default: false, no limitation
                browseBtnClass: 'btn btn-warning btnPrincipal',
            });

        });
        $('.state').val("<?php echo e($user->state); ?>").trigger('change');

    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.masterFront', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>