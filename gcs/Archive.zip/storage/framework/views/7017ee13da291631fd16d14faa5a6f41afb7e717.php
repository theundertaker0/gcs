<?php $__env->startSection('content'); ?>
<div class="row text-center margenInferior paddingSuperior">
    <div class="col-12">
        <img src="<?php echo e(asset('img/logogcs.png')); ?>" alt="Logo GCS" class="logomediano">
    </div>

</div>

<div class="row">
    <div class="col-12 col-md-6 offset-md-3">
        <form method="POST" action="<?php echo e(route('login')); ?>" aria-label="<?php echo e(__('Login')); ?>">
            <?php echo csrf_field(); ?>

            <div class="form-group row">
                <label for="email"><?php echo e(__('Correo electrónico')); ?></label>
                    <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus>

                    <?php if($errors->has('email')): ?>
                        <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('email')); ?></strong>
                </span>
                    <?php endif; ?>
                </div>

            <div class="form-group row">
                <label for="password"><?php echo e(__('Contraseña')); ?></label>
                    <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                    <?php if($errors->has('password')): ?>
                        <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('password')); ?></strong>
                </span>
                    <?php endif; ?>
                </div>

            <div class="form-group row">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                        <label class="form-check-label" for="remember">
                            <?php echo e(__('Recordar contraseña')); ?>

                        </label>
                    </div>
            </div>

            <div class="form-group row text-center">
                <div class="col-12">
                    <button type="submit" class="btn btn-warning btnPrincipal">
                       <span class="fa fa-sign-in-alt"></span> <?php echo e(__('Iniciar Sesión')); ?>

                    </button>
                </div>
                <div class="col-12">
                    <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                        <?php echo e(__('Olvide mi contraseña, solicitar una nueva')); ?>

                    </a>
                </div>
                <div class="col-12">
                    <a class="btn btn-link" href="<?php echo e(route('register')); ?>">
                    <?php echo e(__('Crear una cuenta')); ?>

                    </a>
                </div>
            </div>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.masterFront', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>